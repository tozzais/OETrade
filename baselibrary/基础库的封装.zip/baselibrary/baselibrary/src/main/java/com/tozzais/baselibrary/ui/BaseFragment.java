package com.tozzais.baselibrary.ui;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.tozzais.baselibrary.R;
import com.tozzais.baselibrary.util.toast.ToastCommom;
import com.tozzais.baselibrary.weight.ProgressLayout;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by jumpbox on 16/4/7.
 */
public abstract class BaseFragment<T> extends DialogFragment {
    protected boolean isInit = false; //是否初始化
    protected boolean isLoad = false; //是否加载完成
    protected Activity mActivity;
    public View mRootView;
    protected RelativeLayout mHeaderView;
    protected FrameLayout mContainerView;
    protected ProgressLayout progress_layout;
    private Unbinder unbinder;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mActivity = getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mRootView == null) {
            mRootView = inflater.inflate(getBaseLayout(), container, false);

            int titleLayoutRes = getTitleLayout();
            if (titleLayoutRes > 0) {
                //添加头布局
                mHeaderView =  mRootView.findViewById(R.id.rl_header);
                mHeaderView.addView(LayoutInflater.from(mActivity).inflate(titleLayoutRes, mHeaderView, false));
            }

            //添加内容区域
            mContainerView =  mRootView.findViewById(R.id.content_container);
            mContainerView.addView(LayoutInflater.from(mActivity).inflate(setLayout(), mContainerView, false));

            //加载
            progress_layout =  mRootView.findViewById(R.id.progress_layout);

            EventBus.getDefault().register(this);
            unbinder = ButterKnife.bind(this, mRootView);

            initView1(savedInstanceState);
            initView(savedInstanceState);
        }


        return mRootView;
    }
    @Subscribe
    public void onEvent(T t) {

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadData();
        initListener();
    }

    protected int getTitleLayout() {
        return -1;
    }
    protected int getBaseLayout() {
        return R.layout.base_fragment;
    }

    public void initTitle() {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (unbinder != null){
            unbinder.unbind();
        }
    }

    protected void tsg(String str){
        ToastCommom.createToastConfig().ToastShow(getContext(),str);
    }


    public void initEventBus(){
        boolean registered = EventBus.getDefault().isRegistered(this);
        if (!registered){
            EventBus.getDefault().register(this);
        }
    }

    public abstract int setLayout();

    public  void initView(Bundle savedInstanceState){}

    //主要是为了ListFragmentview的初始化。放置viewpager的预加载导致 RecyclerView和SwipeRefreshLayout的空指针
    public void initView1(Bundle savedInstanceState){}

    public abstract void loadData();

    public  void initListener(){}

    public  void scrollTop(){}

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }


    protected void showProress() {
        progress_layout.showLoading();
    }

    protected void showContent() {
        progress_layout.showContent();
    }

    protected void showError() {
        showError(getString(R.string.loading_error));
    }

    protected void showError(int errorStr) {
        showError(getString(errorStr));
    }

    protected void showError(String errorStr) {
        progress_layout.showError(errorStr, v -> loadData());
    }

    protected void showError(String errorStr, View.OnClickListener clickListener) {
        progress_layout.showError(errorStr, clickListener);
    }

    protected void showError(String errorStr, String btnStr, View.OnClickListener clickListener) {
        progress_layout.showError(errorStr, btnStr,clickListener);
    }
    protected void hideHeader() {
        if (null != mHeaderView) {
            mHeaderView.setVisibility(View.GONE);
        }
    }
}
